import sys
import urllib
import urllib.parse
import xbmcgui
import xbmcplugin

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'F1'})
    li = xbmcgui.ListItem('F1')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Futbol'})
    li = xbmcgui.ListItem('Fútbol')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'folder':
    foldername = args['foldername'][0]

    if foldername == 'F1':
        url = 'plugin://script.module.horus?action=play&id=6b94479c24898700089e6b87d28a3ccc72dc4041'
        li = xbmcgui.ListItem('F1 UHD')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=968627d24eec1c16b51d88e4a4a6c02211e3346e'
        li = xbmcgui.ListItem('F1 multicamara')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=5789ca155323664edd293b848606688edf803f4d'
        li = xbmcgui.ListItem('F1 1080')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=9dad717d99b29a05672166258a77c25b57713dd5'
        li = xbmcgui.ListItem('F1 1080 2')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

        xbmcplugin.endOfDirectory(addon_handle)
    
    elif foldername == 'Futbol':
        url = 'plugin://script.module.horus?action=play&id=dce1579e3a2e5bd29071fca8eae364f1eb3205cf'
        li = xbmcgui.ListItem('LaLiga 4k')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=aa82e7d4f03061f2144a2f4be22f2e2210d42280'
        li = xbmcgui.ListItem('LaLiga 1080')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=7d8c87e057be98f00f22e23b23fbf08999e4b02f'
        li = xbmcgui.ListItem('LaLiga 1080 multiaudio')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id=1969c27658d4c8333ab2c0670802546121a774a5'
        li = xbmcgui.ListItem('LaLiga 1080 multiaudio 2')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        url = 'plugin://script.module.horus?action=play&id='
        li = xbmcgui.ListItem('')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

        xbmcplugin.endOfDirectory(addon_handle)






